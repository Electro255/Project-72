import firebase from 'firebase'
require("@firebase/firestore")

const firebaseConfig = {
  apiKey: "AIzaSyDI3OGualzwdUonZhByWVU7K_NcVtRvyYQ",
  authDomain: "newsletter-f87ce.firebaseapp.com",
  databaseURL: "https://newsletter-f87ce-default-rtdb.firebaseio.com",
  projectId: "newsletter-f87ce",
  storageBucket: "newsletter-f87ce.appspot.com",
  messagingSenderId: "107619811056",
  appId: "1:107619811056:web:477b7cfbf235fc11fdcc35"
};

firebase.initializeApp(firebaseConfig);

export default firebase.firestore()