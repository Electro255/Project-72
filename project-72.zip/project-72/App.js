import * as React from 'react';
import { StyleSheet, Text, View, Image, KeyboardAvoidingView, ToastAndroid } from 'react-native';
import { createBottomTabNavigator } from 'react-navigation-tabs';
import { createAppContainer } from 'react-navigation';
import ReadStory from './screens/ReadStory';
import WriteStory from './screens/WriteStory';

export default class App extends React.Component {
  render() {
    return <AppContainer />;
  }
}

const KeyboardAvoidingComponent = () => {
  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      style={styles.container}
    >
      <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
        <View style={styles.inner}>
          <Text style={styles.header}>Header</Text>
          <TextInput placeholder="StoryTitle" style={styles.textInput} />
          <View style={styles.btnContainer}>
             <Button title="Author" onPress={() => null} />
            <Button title="Submit" onPress={() => null} />
          </View>
        </View>
      </TouchableWithoutFeedback>
    </KeyboardAvoidingView>
  );
};

const ToastAndroidComponent = () => {
  const showToast = () => {
    ToastAndroid.show("Your Story has been submitted!", ToastAndroid.SHORT);
  };


const TabNavigator = createBottomTabNavigator(
  {
    WriteStory: WriteStory,
    ReadStory: ReadStory,
  },
  {
    defaultNavigationOptions: ({ navigation }) => ({
      tabBarIcon: () => {
        const routeName = navigation.state.routeName;
        if (routeName === 'ReadStory') {
          return (
            <Image
              source={require('./images/read.png')}
              style={{ width: 40, height: 40 }}></Image>
          );
        } else if (routeName === 'WriteStory') {
          return (
            <Image
              source={require('./images/write.png')}
              style={{ width: 40, height: 40 }}></Image>
          );
        }
      },
    }),
  }
);

const AppContainer = createAppContainer(TabNavigator);
